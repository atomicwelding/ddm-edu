from package import DDM
