# ddm-edu
DDM Python package for educational purpose. See simd-ddm for efficient ddm software.
